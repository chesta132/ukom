<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Halaman Tidak Ditemukan</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="error-page">
    <div class="error-container">
        <div class="error-content">
            <div class="error-logo">
                <i class="fas fa-store"></i>
            </div>
            <h1 class="error-code">404</h1>
            <h2 class="error-title">Halaman Tidak Ditemukan</h2>
            <p class="error-description">
                Halaman yang Anda cari tidak ada atau telah dipindahkan.
            </p>
            <a href="/" class="btn btn-primary">
                <i class="fas fa-home"></i>
                Kembali ke Dashboard
            </a>
        </div>
    </div>
</body>
</html>
