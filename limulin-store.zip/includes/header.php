<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
auth_check();
$user = current_user();
$page_title = $page_title ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($page_title) ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="app-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-store"></i>
                <span><?= APP_NAME ?></span>
            </div>
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="<?= BASE_URL ?>/index.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
                <i class="fas fa-cash-register"></i><span>Kasir</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/products.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>">
                <i class="fas fa-box"></i><span>Produk</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/categories.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : '' ?>">
                <i class="fas fa-tags"></i><span>Kategori</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/transactions.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'transactions.php' ? 'active' : '' ?>">
                <i class="fas fa-receipt"></i><span>Riwayat Transaksi</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/cashiers.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'cashiers.php' ? 'active' : '' ?>">
                <i class="fas fa-users"></i><span>Daftar Kasir</span>
            </a>
        </nav>
        <div class="sidebar-footer">
            <a href="<?= BASE_URL ?>/pages/profile.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>">
                <i class="fas fa-user-circle"></i><span><?= sanitize($user['username']) ?></span>
            </a>
            <a href="<?= BASE_URL ?>/logout.php" class="nav-item nav-logout">
                <i class="fas fa-sign-out-alt"></i><span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="topbar">
            <button class="mobile-toggle" id="mobileToggle"><i class="fas fa-bars"></i></button>
            <div class="topbar-title"><?= sanitize($page_title) ?></div>
            <div class="topbar-user">
                <i class="fas fa-user"></i> <?= sanitize($user['username']) ?>
            </div>
        </div>
        <div class="content-area">
