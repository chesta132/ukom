        </div><!-- .content-area -->
    </main>
</div><!-- .app-wrapper -->

<div id="overlay" class="overlay"></div>

<!-- Toast Notification -->
<div id="toast" class="toast"></div>

<script src="<?= BASE_URL ?>/js/app.js"></script>
</body>
</html>
