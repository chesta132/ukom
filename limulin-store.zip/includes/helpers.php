<?php
function format_rupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function generate_trx_code() {
    return 'TRX-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function flash_set($key, $msg) {
    session_start_safe();
    $_SESSION['flash'][$key] = $msg;
}

function flash_get($key) {
    session_start_safe();
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $msg;
}

function is_post() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function post($key, $default = '') {
    return $_POST[$key] ?? $default;
}

function get($key, $default = '') {
    return $_GET[$key] ?? $default;
}
