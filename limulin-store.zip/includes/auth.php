<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';

function session_start_safe() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function auth_check() {
    session_start_safe();
    if (empty($_SESSION['cashier_id'])) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    // timeout check
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        session_destroy();
        header('Location: ' . BASE_URL . '/login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function auth_guest() {
    session_start_safe();
    if (!empty($_SESSION['cashier_id'])) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function current_user() {
    session_start_safe();
    if (empty($_SESSION['cashier_id'])) return null;
    return DB::fetchOne('SELECT * FROM kasir WHERE id = ?', [$_SESSION['cashier_id']]);
}

function login($username, $password) {
    $user = DB::fetchOne('SELECT * FROM kasir WHERE username = ?', [$username]);
    if ($user && password_verify($password, $user['password'])) {
        session_start_safe();
        $_SESSION['cashier_id'] = $user['id'];
        $_SESSION['cashier_name'] = $user['username'];
        $_SESSION['last_activity'] = time();
        return true;
    }
    return false;
}

function logout() {
    session_start_safe();
    session_destroy();
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}
