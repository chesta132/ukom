<?php
require_once __DIR__ . '/../config.php';

class DB {
    private static $mysqli = null;

    public static function connect() {
        if (self::$mysqli === null) {
            self::$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if (self::$mysqli->connect_error) {
                throw new Exception('DB Connection failed: ' . self::$mysqli->connect_error);
            }
            self::$mysqli->set_charset(DB_CHARSET);
        }
        return self::$mysqli;
    }

    /**
     * Execute a query with optional params (positional ? placeholders).
     * Returns mysqli_stmt on success.
     */
    public static function query($sql, $params = []) {
        $conn = self::connect();
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception('Prepare failed: ' . $conn->error . ' | SQL: ' . $sql);
        }
        if (!empty($params)) {
            $types = '';
            foreach ($params as $p) {
                if (is_int($p))    $types .= 'i';
                elseif (is_float($p)) $types .= 'd';
                else               $types .= 's';
            }
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        return $stmt;
    }

    public static function fetchAll($sql, $params = []) {
        $stmt = self::query($sql, $params);
        $result = $stmt->get_result();
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public static function fetchOne($sql, $params = []) {
        $stmt = self::query($sql, $params);
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        return $row ?: null;
    }

    public static function insert($table, $data) {
        $cols = implode(',', array_map(function($k) { return "`$k`"; }, array_keys($data)));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        self::query("INSERT INTO `$table` ($cols) VALUES ($placeholders)", array_values($data));
        return self::connect()->insert_id;
    }

    public static function update($table, $data, $where, $whereParams = []) {
        $set = implode(',', array_map(function($k) { return "`$k`=?"; }, array_keys($data)));
        $params = array_merge(array_values($data), $whereParams);
        return self::query("UPDATE `$table` SET $set WHERE $where", $params);
    }

    public static function delete($table, $where, $params = []) {
        return self::query("DELETE FROM `$table` WHERE $where", $params);
    }
}