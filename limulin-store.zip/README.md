# Limulin Store - POS System

**Website**: Limulin Store  
**Alamat**: Jl Wibawa Mukti II, Jatisari Jatiasih Kota Bekasi  
**Stack**: PHP 7 Native, MySQL 5.7, Apache2 (LAMP)

---

## Fitur
- ✅ Kasir POS dengan input SKU / scan barcode
- ✅ Manajemen Produk (CRUD + generate SKU otomatis)
- ✅ Manajemen Kategori dengan alias 3 huruf
- ✅ Riwayat Transaksi dengan filter & detail
- ✅ Daftar Kasir
- ✅ Auth (Login, Register dengan kode rahasia, Logout)
- ✅ Profil kasir - view & edit terpisah
- ✅ Print / Download struk (open print dialog / save PDF)
- ✅ Responsive mobile-friendly

---

## Cara Install

### Opsi 1: Docker

```bash
# Clone / extract project
cd limulin-store

# Jalankan Docker
docker-compose up -d

# Akses web
http://localhost:8080

# phpMyAdmin
http://localhost:8081
```

Database akan otomatis di-import dari `database.sql`.

### Opsi 2: XAMPP

1. Copy folder `limulin-store` ke `htdocs/`
2. Buka phpMyAdmin → import `database.sql`
3. Edit `config.php` jika perlu:
   - `DB_HOST` = `localhost`
   - `DB_USER` = `root`
   - `DB_PASS` = `` (kosong untuk XAMPP default)
   - `BASE_URL` = `http://localhost/limulin-store`
4. Akses: `http://localhost/limulin-store`

### Opsi 3: Ubuntu Server (LAMP)

```bash
# Install dependencies
sudo apt update
sudo apt install apache2 mysql-server php7.4 php7.4-mysql -y

# Copy files
sudo cp -r limulin-store /var/www/html/

# Setup database
mysql -u root -p < /var/www/html/limulin-store/database.sql

# Edit config.php sesuai DB credentials

# Restart Apache
sudo systemctl restart apache2
```

---

## Login Default

| Field    | Value                   |
|----------|-------------------------|
| Username | admin                   |
| Password | password                |
| Email    | admin@limulinstore.com  |

---

## Kode Rahasia Registrasi

Kode rahasia default: **`LIMULIN2024SECRET`**

Ubah di `config.php`:
```php
define('APP_SECRET', 'LIMULIN2024SECRET');
```

---

## Format SKU

SKU digenerate otomatis: `ALIAS_KATEGORI-NAMASINGKAT-BERAT`

Contoh:
- Aqua Botol 600ml di kategori Minuman (MIN) → `MIN-AQUABOT-600`
- Indomie Goreng 85g di kategori Makanan (MAK) → `MAK-INDOMIEG-85`

---

## Struktur File

```
limulin-store/
├── config.php          ← Konfigurasi utama
├── index.php           ← Halaman kasir POS
├── login.php
├── register.php
├── logout.php
├── database.sql        ← Schema + seed data
├── docker-compose.yml
├── css/
│   └── style.css
├── js/
│   └── app.js
├── includes/
│   ├── db.php
│   ├── auth.php
│   ├── helpers.php
│   ├── header.php
│   └── footer.php
├── pages/
│   ├── products.php
│   ├── categories.php
│   ├── transactions.php
│   ├── cashiers.php
│   ├── profile.php
│   └── profile_edit.php
└── api/
    ├── get_product.php
    ├── search_product.php
    ├── process_transaction.php
    └── download_receipt.php
```
