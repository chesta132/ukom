/* ============================================================
   LIMULIN STORE - app.js
   ============================================================ */

// ============================================================
// Sidebar Toggle
// ============================================================
const sidebar = document.getElementById('sidebar');
const mainContent = document.querySelector('.main-content');
const sidebarToggle = document.getElementById('sidebarToggle');
const mobileToggle = document.getElementById('mobileToggle');
const overlay = document.getElementById('overlay');

if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
    });
}
if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('active');
    });
}
if (overlay) {
    overlay.addEventListener('click', () => {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
    });
}

// ============================================================
// Toast
// ============================================================
function showToast(msg, type = 'default', duration = 3000) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.className = 'toast show ' + type;
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.classList.remove('show'); }, duration);
}

// ============================================================
// Confirm Dialog
// ============================================================
function confirmAction(title, msg, onConfirm) {
    let overlay = document.getElementById('confirmOverlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'confirmOverlay';
        overlay.className = 'confirm-overlay';
        overlay.innerHTML = `
            <div class="confirm-box">
                <div class="confirm-icon text-danger"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="confirm-title" id="confirmTitle"></div>
                <div class="confirm-msg" id="confirmMsg"></div>
                <div class="confirm-actions">
                    <button class="btn btn-secondary" id="confirmCancel">Batal</button>
                    <button class="btn btn-danger" id="confirmOk">Hapus</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        document.getElementById('confirmCancel').addEventListener('click', () => {
            overlay.classList.remove('active');
        });
    }
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMsg').textContent = msg;
    overlay.classList.add('active');
    const okBtn = document.getElementById('confirmOk');
    okBtn.onclick = () => {
        overlay.classList.remove('active');
        onConfirm();
    };
}

// ============================================================
// Modal helpers
// ============================================================
function openModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('active');
}
function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('active');
}

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-close') || e.target.closest('.modal-close')) {
        const modal = e.target.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
    }
    // click outside modal
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

// ============================================================
// Auto show flash alerts from hidden div
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    const flash = document.getElementById('flashToast');
    if (flash) {
        showToast(flash.dataset.msg, flash.dataset.type, 4000);
    }
});
