<?php
$page_title = 'Manajemen Kategori';
require_once __DIR__ . '/../includes/header.php';

$action = post('action');
$error = '';

if (is_post()) {
    if ($action === 'add' || $action === 'edit') {
        $nama  = trim(post('nama'));
        $alias = strtoupper(trim(post('alias')));

        if (!$nama || !$alias) {
            $error = 'Nama dan alias wajib diisi';
        } elseif (strlen($alias) > 3) {
            $error = 'Alias maksimal 3 karakter';
        } else {
            if ($action === 'add') {
                $dup = DB::fetchOne('SELECT id FROM kategori WHERE alias = ?', [$alias]);
                if ($dup) { $error = 'Alias sudah digunakan'; }
                else {
                    DB::insert('kategori', compact('nama', 'alias'));
                    flash_set('success', 'Kategori berhasil ditambahkan');
                    redirect(BASE_URL . '/pages/categories.php');
                }
            } else {
                $id = (int)post('id');
                $dup = DB::fetchOne('SELECT id FROM kategori WHERE alias = ? AND id != ?', [$alias, $id]);
                if ($dup) { $error = 'Alias sudah digunakan'; }
                else {
                    DB::update('kategori', compact('nama', 'alias'), 'id = ?', [$id]);
                    flash_set('success', 'Kategori berhasil diperbarui');
                    redirect(BASE_URL . '/pages/categories.php');
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        $hasProduct = DB::fetchOne('SELECT id FROM produk WHERE kategori_id = ?', [$id]);
        if ($hasProduct) {
            flash_set('error', 'Kategori tidak bisa dihapus karena masih ada produk');
        } else {
            DB::delete('kategori', 'id = ?', [$id]);
            flash_set('success', 'Kategori berhasil dihapus');
        }
        redirect(BASE_URL . '/pages/categories.php');
    }
}

$categories = DB::fetchAll('SELECT k.*, COUNT(p.id) as product_count FROM kategori k LEFT JOIN produk p ON p.kategori_id = k.id GROUP BY k.id ORDER BY k.nama');
$flash = flash_get('success');
$flashErr = flash_get('error');
?>

<?php if ($flash): ?><div id="flashToast" data-msg="<?= sanitize($flash) ?>" data-type="success" style="display:none"></div><?php endif; ?>
<?php if ($flashErr): ?><div id="flashToast" data-msg="<?= sanitize($flashErr) ?>" data-type="error" style="display:none"></div><?php endif; ?>

<div class="d-flex justify-between align-center mb-2">
    <div></div>
    <button class="btn btn-primary" onclick="openModal('addModal')"><i class="fas fa-plus"></i> Tambah Kategori</button>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-tags"></i> Daftar Kategori</div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger" style="margin:16px 20px"><i class="fas fa-exclamation-circle"></i><?= sanitize($error) ?></div><?php endif; ?>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Nama Kategori</th><th>Alias (SKU)</th><th>Jumlah Produk</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($categories)): ?>
            <tr><td colspan="5" class="text-center text-muted" style="padding:30px">Belum ada kategori</td></tr>
            <?php else: ?>
            <?php foreach ($categories as $i => $c): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><strong><?= sanitize($c['nama']) ?></strong></td>
                <td><span class="badge badge-blue"><?= sanitize($c['alias']) ?></span></td>
                <td><?= $c['product_count'] ?> produk</td>
                <td>
                    <button class="btn btn-sm btn-outline btn-icon" onclick='editCat(<?= json_encode($c) ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger btn-icon" onclick="deleteCat(<?= $c['id'] ?>, '<?= addslashes($c['nama']) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div id="addModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-plus"></i> Tambah Kategori</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Kategori *</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias (maks 3 huruf, untuk SKU) *</label>
                    <input type="text" name="alias" class="form-control" maxlength="3" style="text-transform:uppercase" required>
                    <div class="form-error">Contoh: Minuman → MIN, Snack → SNK</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Batal</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-edit"></i> Edit Kategori</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Kategori *</label>
                    <input type="text" name="nama" id="editNama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias (maks 3 huruf) *</label>
                    <input type="text" name="alias" id="editAlias" class="form-control" maxlength="3" style="text-transform:uppercase" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Batal</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
            </div>
        </form>
    </div>
</div>

<form id="deleteForm" method="POST" style="display:none">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function editCat(c) {
    document.getElementById('editId').value = c.id;
    document.getElementById('editNama').value = c.nama;
    document.getElementById('editAlias').value = c.alias;
    openModal('editModal');
}
function deleteCat(id, name) {
    confirmAction('Hapus Kategori', 'Yakin hapus kategori "' + name + '"?', () => {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteForm').submit();
    });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
