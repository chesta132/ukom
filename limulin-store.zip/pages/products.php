<?php
$page_title = 'Manajemen Produk';
require_once __DIR__ . '/../includes/header.php';

// Handle actions
$action = post('action');
$error = '';

if (is_post()) {
    if ($action === 'add' || $action === 'edit') {
        $name        = trim(post('name'));
        $kategori_id = (int)post('kategori_id');
        $berat       = (int)post('berat');
        $price       = (float)post('price');
        $discount    = min(100, max(0, (float)post('discount')));
        $stock       = (int)post('stock');

        if (!$name || !$kategori_id || !$price) {
            $error = 'Nama, kategori, dan harga wajib diisi';
        } else {
            // Build SKU: ALIAS-NAMASINGKAT-BERAT
            $kat = DB::fetchOne('SELECT alias FROM kategori WHERE id = ?', [$kategori_id]);
            $nameSlug = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', substr($name, 0, 8)));
            $sku = strtoupper($kat['alias']) . '-' . $nameSlug . '-' . $berat;

            if ($action === 'add') {
                // ensure unique sku
                $existing = DB::fetchOne('SELECT id FROM produk WHERE sku = ?', [$sku]);
                if ($existing) $sku .= '-' . substr(uniqid(), -3);
                DB::insert('produk', compact('name', 'sku', 'kategori_id', 'berat', 'price', 'discount', 'stock') + ['sold' => 0]);
                flash_set('success', 'Produk berhasil ditambahkan');
            } else {
                $id = (int)post('id');
                DB::update('produk', compact('name', 'kategori_id', 'berat', 'price', 'discount', 'stock'), 'id = ?', [$id]);
                flash_set('success', 'Produk berhasil diperbarui');
            }
            redirect(BASE_URL . '/pages/products.php');
        }
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        DB::delete('produk', 'id = ?', [$id]);
        flash_set('success', 'Produk berhasil dihapus');
        redirect(BASE_URL . '/pages/products.php');
    }
}

// Pagination & search
$page = max(1, (int)get('page', 1));
$limit = 15;
$offset = ($page - 1) * $limit;
$search = get('search');
$katFilter = (int)get('kategori');

$whereClause = '1=1';
$params = [];
if ($search) { $whereClause .= ' AND (p.name LIKE ? OR p.sku LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($katFilter) { $whereClause .= ' AND p.kategori_id = ?'; $params[] = $katFilter; }

$total = DB::fetchOne("SELECT COUNT(*) as c FROM produk p WHERE $whereClause", $params)['c'];
$products = DB::fetchAll("SELECT p.*, k.nama as kat_nama FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id WHERE $whereClause ORDER BY p.id DESC LIMIT $limit OFFSET $offset", $params);

$categories = DB::fetchAll('SELECT * FROM kategori ORDER BY nama');
$pages = ceil($total / $limit);
$flash = flash_get('success');
?>

<?php if ($flash): ?><div id="flashToast" data-msg="<?= sanitize($flash) ?>" data-type="success" style="display:none"></div><?php endif; ?>

<div class="d-flex justify-between align-center mb-2">
    <div class="filter-bar">
        <input type="text" id="searchInput" class="form-control" placeholder="Cari produk / SKU..." value="<?= sanitize($search) ?>" onchange="applyFilter()">
        <select id="katFilter" class="form-control" onchange="applyFilter()">
            <option value="">Semua Kategori</option>
            <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $katFilter == $c['id'] ? 'selected' : '' ?>><?= sanitize($c['nama']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button class="btn btn-primary" onclick="openModal('addModal')"><i class="fas fa-plus"></i> Tambah Produk</button>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-box"></i> Daftar Produk (<?= $total ?>)</div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger" style="margin:16px 20px"><i class="fas fa-exclamation-circle"></i><?= sanitize($error) ?></div><?php endif; ?>
    <div class="table-wrapper">
        <table>
            <thead><tr>
                <th>#</th><th>SKU</th><th>Nama</th><th>Kategori</th><th>Berat</th><th>Harga</th><th>Diskon</th><th>Stok</th><th>Terjual</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($products)): ?>
            <tr><td colspan="10" class="text-center text-muted" style="padding:30px">Tidak ada produk</td></tr>
            <?php else: ?>
            <?php foreach ($products as $i => $p): ?>
            <tr>
                <td><?= $offset + $i + 1 ?></td>
                <td><code style="font-size:0.8rem"><?= sanitize($p['sku']) ?></code></td>
                <td><strong><?= sanitize($p['name']) ?></strong></td>
                <td><span class="badge badge-blue"><?= sanitize($p['kat_nama'] ?? '-') ?></span></td>
                <td><?= $p['berat'] ?> g</td>
                <td><?= format_rupiah($p['price']) ?></td>
                <td><?= $p['discount'] > 0 ? '<span class="badge badge-red">'.$p['discount'].'%</span>' : '-' ?></td>
                <td><?= $p['stock'] > 0 ? '<span class="badge badge-green">'.$p['stock'].'</span>' : '<span class="badge badge-red">0</span>' ?></td>
                <td><?= $p['sold'] ?></td>
                <td>
                    <button class="btn btn-sm btn-outline btn-icon" onclick='editProduct(<?= json_encode($p) ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger btn-icon" onclick="deleteProduct(<?= $p['id'] ?>, '<?= addslashes($p['name']) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div style="padding:14px 20px;border-top:1px solid var(--gray-200)">
        <div class="pagination">
            <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&kategori=<?= $katFilter ?>" class="page-item <?= $page == $i ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Add Modal -->
<div id="addModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-plus"></i> Tambah Produk</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Produk *</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori_id" class="form-control" required>
                            <option value="">-- Pilih --</option>
                            <?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= sanitize($c['nama']) ?> (<?= sanitize($c['alias']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Berat (gram)</label>
                        <input type="number" name="berat" class="form-control" value="0" min="0">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Harga (Rp) *</label>
                        <input type="number" name="price" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <input type="number" name="discount" class="form-control" value="0" min="0" max="100">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stock" class="form-control" value="0" min="0">
                </div>
                <small class="text-muted">SKU akan digenerate otomatis: ALIAS_KAT-NAMA-BERAT</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Batal</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-edit"></i> Edit Produk</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">SKU (auto)</label>
                    <input type="text" id="editSku" class="form-control" readonly style="background:var(--gray-100)">
                </div>
                <div class="form-group">
                    <label class="form-label">Nama Produk *</label>
                    <input type="text" name="name" id="editName" class="form-control" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori_id" id="editKategori" class="form-control" required>
                            <option value="">-- Pilih --</option>
                            <?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= sanitize($c['nama']) ?> (<?= sanitize($c['alias']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Berat (gram)</label>
                        <input type="number" name="berat" id="editBerat" class="form-control" min="0">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Harga (Rp) *</label>
                        <input type="number" name="price" id="editPrice" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <input type="number" name="discount" id="editDiscount" class="form-control" min="0" max="100">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stock" id="editStock" class="form-control" min="0">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Batal</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Form -->
<form id="deleteForm" method="POST" style="display:none">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function editProduct(p) {
    document.getElementById('editId').value = p.id;
    document.getElementById('editSku').value = p.sku;
    document.getElementById('editName').value = p.name;
    document.getElementById('editKategori').value = p.kategori_id;
    document.getElementById('editBerat').value = p.berat;
    document.getElementById('editPrice').value = p.price;
    document.getElementById('editDiscount').value = p.discount;
    document.getElementById('editStock').value = p.stock;
    openModal('editModal');
}
function deleteProduct(id, name) {
    confirmAction('Hapus Produk', 'Yakin hapus produk "' + name + '"?', () => {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteForm').submit();
    });
}
function applyFilter() {
    const s = document.getElementById('searchInput').value;
    const k = document.getElementById('katFilter').value;
    window.location.href = '?search=' + encodeURIComponent(s) + '&kategori=' + k;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
