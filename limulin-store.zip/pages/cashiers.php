<?php
$page_title = 'Daftar Kasir';
require_once __DIR__ . '/../includes/header.php';

$cashiers = DB::fetchAll(
    'SELECT k.*, COUNT(t.id) as trx_count FROM kasir k LEFT JOIN transaksi t ON t.kasir_id = k.id GROUP BY k.id ORDER BY k.id'
);
$flash = flash_get('success');
?>

<?php if ($flash): ?><div id="flashToast" data-msg="<?= sanitize($flash) ?>" data-type="success" style="display:none"></div><?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-users"></i> Daftar Kasir (<?= count($cashiers) ?>)</div>
        <a href="<?= BASE_URL ?>/register.php" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Tambah Kasir</a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Username</th><th>Email</th><th>Jumlah Transaksi</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (empty($cashiers)): ?>
            <tr><td colspan="5" class="text-center text-muted" style="padding:30px">Belum ada kasir</td></tr>
            <?php else: ?>
            <?php foreach ($cashiers as $i => $c): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td>
                    <div class="d-flex align-center gap-2">
                        <div style="width:32px;height:32px;background:var(--blue-pale);color:var(--blue-primary);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0">
                            <?= strtoupper(substr($c['username'], 0, 1)) ?>
                        </div>
                        <strong><?= sanitize($c['username']) ?></strong>
                        <?= $c['id'] == $_SESSION['cashier_id'] ? '<span class="badge badge-green">Anda</span>' : '' ?>
                    </div>
                </td>
                <td><?= sanitize($c['email']) ?></td>
                <td><?= $c['trx_count'] ?> transaksi</td>
                <td><span class="badge badge-green">Aktif</span></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
