<?php
$page_title = 'Riwayat Transaksi';
require_once __DIR__ . '/../includes/header.php';

$page   = max(1, (int)get('page', 1));
$limit  = 15;
$offset = ($page - 1) * $limit;
$search = get('search');
$dateFrom = get('date_from');
$dateTo   = get('date_to');

$where  = '1=1';
$params = [];
if ($search) { $where .= ' AND (t.kode LIKE ? OR k.username LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($dateFrom) { $where .= ' AND DATE(t.created_at) >= ?'; $params[] = $dateFrom; }
if ($dateTo)   { $where .= ' AND DATE(t.created_at) <= ?'; $params[] = $dateTo; }

$total = DB::fetchOne("SELECT COUNT(*) as c FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id WHERE $where", $params)['c'];
$transactions = DB::fetchAll(
    "SELECT t.*, k.username as cashier_name FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id WHERE $where ORDER BY t.id DESC LIMIT $limit OFFSET $offset",
    array_merge($params)
);

// Summary stats
$todayTotal = DB::fetchOne("SELECT COALESCE(SUM(grand_total),0) as s FROM transaksi WHERE DATE(created_at) = CURDATE()")['s'];
$monthTotal = DB::fetchOne("SELECT COALESCE(SUM(grand_total),0) as s FROM transaksi WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")['s'];
$todayTrx   = DB::fetchOne("SELECT COUNT(*) as c FROM transaksi WHERE DATE(created_at) = CURDATE()")['c'];

$pages = ceil($total / $limit);
?>

<!-- Stats -->
<div class="stats-row">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-receipt"></i></div>
        <div class="stat-info">
            <div class="stat-label">Transaksi Hari Ini</div>
            <div class="stat-value"><?= $todayTrx ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-coins"></i></div>
        <div class="stat-info">
            <div class="stat-label">Omset Hari Ini</div>
            <div class="stat-value"><?= format_rupiah($todayTotal) ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow"><i class="fas fa-calendar-alt"></i></div>
        <div class="stat-info">
            <div class="stat-label">Omset Bulan Ini</div>
            <div class="stat-value"><?= format_rupiah($monthTotal) ?></div>
        </div>
    </div>
</div>

<!-- Filter Bar -->
<div class="filter-bar mb-2">
    <input type="text" id="searchInput" class="form-control" placeholder="Kode transaksi / kasir..." value="<?= sanitize($search) ?>" onchange="applyFilter()">
    <input type="date" id="dateFrom" class="form-control" value="<?= sanitize($dateFrom) ?>" onchange="applyFilter()">
    <input type="date" id="dateTo" class="form-control" value="<?= sanitize($dateTo) ?>" onchange="applyFilter()">
    <button class="btn btn-secondary" onclick="clearFilter()"><i class="fas fa-times"></i> Reset</button>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-history"></i> Riwayat Transaksi (<?= $total ?>)</div>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Kode</th><th>Kasir</th><th>Items</th><th>Total</th><th>Waktu</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($transactions)): ?>
            <tr><td colspan="7" class="text-center text-muted" style="padding:30px">Tidak ada transaksi</td></tr>
            <?php else: ?>
            <?php foreach ($transactions as $i => $t):
                $products = json_decode($t['products'], true);
                $itemCount = array_sum(array_column($products, 'qty'));
            ?>
            <tr>
                <td><?= $offset + $i + 1 ?></td>
                <td><code><?= sanitize($t['kode']) ?></code></td>
                <td><?= sanitize($t['cashier_name']) ?></td>
                <td><?= $itemCount ?> item</td>
                <td class="fw-bold text-primary"><?= format_rupiah($t['grand_total']) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick='viewTrx(<?= json_encode($t) ?>)'><i class="fas fa-eye"></i> Detail</button>
                    <a class="btn btn-sm btn-secondary" href="<?= BASE_URL ?>/api/download_receipt.php?id=<?= $t['id'] ?>" target="_blank"><i class="fas fa-print"></i> Struk</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div style="padding:14px 20px;border-top:1px solid var(--gray-200)">
        <div class="pagination">
            <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&date_from=<?= urlencode($dateFrom) ?>&date_to=<?= urlencode($dateTo) ?>" class="page-item <?= $page == $i ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Detail Modal -->
<div id="detailModal" class="modal-overlay">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-receipt"></i> Detail Transaksi</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" id="detailContent"></div>
        <div class="modal-footer">
            <button class="btn btn-secondary modal-close">Tutup</button>
            <a id="printBtn" class="btn btn-outline" href="#" target="_blank"><i class="fas fa-print"></i> Print Struk</a>
        </div>
    </div>
</div>

<script>
function applyFilter() {
    const s = document.getElementById('searchInput').value;
    const df = document.getElementById('dateFrom').value;
    const dt = document.getElementById('dateTo').value;
    window.location.href = '?search=' + encodeURIComponent(s) + '&date_from=' + encodeURIComponent(df) + '&date_to=' + encodeURIComponent(dt);
}
function clearFilter() {
    window.location.href = '?';
}
function fmtRp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
function escHtml(s) { if (!s) return ''; return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function viewTrx(t) {
    const products = JSON.parse(typeof t.products === 'string' ? t.products : JSON.stringify(t.products));
    let rows = products.map(p => {
        const net = p.price - (p.price * (p.discount||0) / 100);
        return `<tr>
            <td>${escHtml(p.name)}${p.discount > 0 ? ' <span class="badge badge-red">-'+p.discount+'%</span>' : ''}</td>
            <td><code>${escHtml(p.sku)}</code></td>
            <td class="text-right">${fmtRp(p.price)}</td>
            <td class="text-center">${p.qty}</td>
            <td class="text-right fw-bold">${fmtRp(net * p.qty)}</td>
        </tr>`;
    }).join('');

    document.getElementById('detailContent').innerHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;padding:12px;background:var(--gray-50);border-radius:8px">
            <div><div class="text-muted" style="font-size:.8rem">Kode</div><strong>${escHtml(t.kode)}</strong></div>
            <div><div class="text-muted" style="font-size:.8rem">Kasir</div><strong>${escHtml(t.cashier_name)}</strong></div>
            <div><div class="text-muted" style="font-size:.8rem">Tanggal</div>${new Date(t.created_at).toLocaleString('id-ID')}</div>
            <div><div class="text-muted" style="font-size:.8rem">Total</div><strong class="text-primary">${fmtRp(t.grand_total)}</strong></div>
        </div>
        <div class="table-wrapper">
            <table>
                <thead><tr><th>Produk</th><th>SKU</th><th class="text-right">Harga</th><th class="text-center">Qty</th><th class="text-right">Subtotal</th></tr></thead>
                <tbody>${rows}</tbody>
            </table>
        </div>`;
    document.getElementById('printBtn').href = '<?= BASE_URL ?>/api/download_receipt.php?id=' + t.id;
    openModal('detailModal');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
