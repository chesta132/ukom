<?php
$page_title = 'Profil Saya';
require_once __DIR__ . '/../includes/header.php';

$flash = flash_get('success');
$me = $user;
$trxCount = DB::fetchOne('SELECT COUNT(*) as c FROM transaksi WHERE kasir_id = ?', [$me['id']])['c'];
$trxTotal = DB::fetchOne('SELECT COALESCE(SUM(grand_total),0) as s FROM transaksi WHERE kasir_id = ?', [$me['id']])['s'];
?>

<?php if ($flash): ?><div id="flashToast" data-msg="<?= sanitize($flash) ?>" data-type="success" style="display:none"></div><?php endif; ?>

<div class="profile-layout">
    <!-- Left: Profile Card -->
    <div class="card">
        <div class="card-body profile-card">
            <div class="profile-avatar"><?= strtoupper(substr($me['username'], 0, 1)) ?></div>
            <div class="profile-name"><?= sanitize($me['username']) ?></div>
            <div class="profile-email"><?= sanitize($me['email']) ?></div>
            <a href="<?= BASE_URL ?>/pages/profile_edit.php" class="btn btn-primary mt-2" style="width:100%;justify-content:center">
                <i class="fas fa-edit"></i> Edit Profil
            </a>
            <div class="profile-detail">
                <div class="profile-field">
                    <span class="profile-field-label">Total Transaksi</span>
                    <span class="profile-field-value"><?= $trxCount ?> transaksi</span>
                </div>
                <div class="profile-field">
                    <span class="profile-field-label">Total Omset</span>
                    <span class="profile-field-value"><?= format_rupiah($trxTotal) ?></span>
                </div>
                <div class="profile-field">
                    <span class="profile-field-label">ID Kasir</span>
                    <span class="profile-field-value">#<?= $me['id'] ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Right: Info & Stats -->
    <div style="display:flex;flex-direction:column;gap:16px;">
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-info-circle"></i> Informasi Akun</div></div>
            <div class="card-body">
                <table style="width:100%">
                    <tr><td style="padding:8px 0;color:var(--gray-500);width:40%">Username</td><td style="padding:8px 0;font-weight:600"><?= sanitize($me['username']) ?></td></tr>
                    <tr><td style="padding:8px 0;color:var(--gray-500);border-top:1px solid var(--gray-100)">Email</td><td style="padding:8px 0;border-top:1px solid var(--gray-100)"><?= sanitize($me['email']) ?></td></tr>
                    <tr><td style="padding:8px 0;color:var(--gray-500);border-top:1px solid var(--gray-100)">Status</td><td style="padding:8px 0;border-top:1px solid var(--gray-100)"><span class="badge badge-green">Aktif</span></td></tr>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-history"></i> Transaksi Terbaru Saya</div></div>
            <div class="table-wrapper">
                <?php $myTrx = DB::fetchAll('SELECT * FROM transaksi WHERE kasir_id = ? ORDER BY id DESC LIMIT 5', [$me['id']]); ?>
                <table>
                    <thead><tr><th>Kode</th><th>Total</th><th>Waktu</th><th>Aksi</th></tr></thead>
                    <tbody>
                    <?php if (empty($myTrx)): ?>
                    <tr><td colspan="4" class="text-center text-muted" style="padding:20px">Belum ada transaksi</td></tr>
                    <?php else: ?>
                    <?php foreach ($myTrx as $t): ?>
                    <tr>
                        <td><code><?= sanitize($t['kode']) ?></code></td>
                        <td class="fw-bold text-primary"><?= format_rupiah($t['grand_total']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
                        <td><a href="<?= BASE_URL ?>/api/download_receipt.php?id=<?= $t['id'] ?>" target="_blank" class="btn btn-sm btn-outline"><i class="fas fa-print"></i> Struk</a></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
