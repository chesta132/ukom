<?php
$page_title = 'Edit Profil';
require_once __DIR__ . '/../includes/header.php';

$me = $user;
$error = '';

if (is_post()) {
    $username   = trim(post('username'));
    $email      = trim(post('email'));
    $oldPassword = post('old_password');
    $newPassword = post('new_password');
    $confirmPw   = post('confirm_password');

    if (!$username || !$email) {
        $error = 'Username dan email wajib diisi';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } else {
        $dup = DB::fetchOne('SELECT id FROM kasir WHERE (username = ? OR email = ?) AND id != ?', [$username, $email, $me['id']]);
        if ($dup) {
            $error = 'Username atau email sudah digunakan kasir lain';
        } else {
            $updateData = ['username' => $username, 'email' => $email];

            if ($newPassword) {
                if (!password_verify($oldPassword, $me['password'])) {
                    $error = 'Password lama tidak sesuai';
                } elseif (strlen($newPassword) < 6) {
                    $error = 'Password baru minimal 6 karakter';
                } elseif ($newPassword !== $confirmPw) {
                    $error = 'Konfirmasi password tidak cocok';
                } else {
                    $updateData['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
                }
            }

            if (!$error) {
                DB::update('kasir', $updateData, 'id = ?', [$me['id']]);
                $_SESSION['cashier_name'] = $username;
                flash_set('success', 'Profil berhasil diperbarui');
                redirect(BASE_URL . '/pages/profile.php');
            }
        }
    }
}
?>

<div style="max-width:600px;">
    <div class="mb-2">
        <a href="<?= BASE_URL ?>/pages/profile.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali ke Profil</a>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title"><i class="fas fa-edit"></i> Edit Profil</div></div>
        <div class="card-body">
            <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?= sanitize($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-control" value="<?= sanitize(post('username') ?: $me['username']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" value="<?= sanitize(post('email') ?: $me['email']) ?>" required>
                </div>

                <div style="border-top:1px solid var(--gray-200);margin:20px 0;padding-top:20px;">
                    <h4 style="font-size:.95rem;color:var(--gray-600);margin-bottom:14px"><i class="fas fa-key"></i> Ganti Password (opsional)</h4>
                    <div class="form-group">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="old_password" class="form-control">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Password Baru</label>
                            <input type="password" name="new_password" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Konfirmasi Password Baru</label>
                            <input type="password" name="confirm_password" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Perubahan</button>
                    <a href="<?= BASE_URL ?>/pages/profile.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
