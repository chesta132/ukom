<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

auth_guest();

$error = '';
$success = '';

if (is_post()) {
    $username = trim(post('username'));
    $email    = trim(post('email'));
    $password = post('password');
    $confirm  = post('confirm_password');
    $secret   = post('secret');

    if (empty($username) || empty($email) || empty($password) || empty($secret)) {
        $error = 'Semua field wajib diisi.';
    } elseif ($secret !== APP_SECRET) {
        $error = 'Kode rahasia tidak valid.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } else {
        $existing = DB::fetchOne('SELECT id FROM kasir WHERE username = ? OR email = ?', [$username, $email]);
        if ($existing) {
            $error = 'Username atau email sudah terdaftar.';
        } else {
            DB::insert('kasir', [
                'username' => $username,
                'email'    => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            $success = 'Akun berhasil dibuat! Silakan login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <i class="fas fa-store"></i>
            <h1><?= APP_NAME ?></h1>
            <p>Pendaftaran Kasir</p>
        </div>
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?= sanitize($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i><?= sanitize($success) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="<?= sanitize(post('username')) ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= sanitize(post('email')) ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Konfirmasi Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Kode Rahasia</label>
                <input type="password" name="secret" class="form-control" placeholder="Hubungi admin untuk kode" required>
            </div>
            <button type="submit" class="btn btn-primary w-100" style="justify-content:center;padding:10px;">
                <i class="fas fa-user-plus"></i> Daftar
            </button>
        </form>
        <div class="auth-footer">
            Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Login di sini</a>
        </div>
    </div>
</div>
</body>
</html>
