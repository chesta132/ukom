-- ============================================================
-- LIMULIN STORE - Database Schema
-- MySQL 5.7 Compatible
-- ============================================================

CREATE DATABASE IF NOT EXISTS `limulin_store` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `limulin_store`;

-- Kasir (Cashier)
CREATE TABLE IF NOT EXISTS `kasir` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username`   VARCHAR(100) NOT NULL UNIQUE,
    `email`      VARCHAR(150) NOT NULL UNIQUE,
    `password`   VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Kategori (Category)
CREATE TABLE IF NOT EXISTS `kategori` (
    `id`    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nama`  VARCHAR(100) NOT NULL,
    `alias` CHAR(3) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Produk (Product)
CREATE TABLE IF NOT EXISTS `produk` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(200) NOT NULL,
    `sku`         VARCHAR(50) NOT NULL UNIQUE,
    `kategori_id` INT UNSIGNED NOT NULL,
    `berat`       INT UNSIGNED DEFAULT 0 COMMENT 'gram',
    `price`       DECIMAL(12,2) NOT NULL DEFAULT 0,
    `discount`    DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'percent 0-100',
    `stock`       INT NOT NULL DEFAULT 0,
    `sold`        INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`kategori_id`) REFERENCES `kategori`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Transaksi (Transaction)
CREATE TABLE IF NOT EXISTS `transaksi` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kode`        VARCHAR(20) NOT NULL UNIQUE,
    `kasir_id`    INT UNSIGNED NOT NULL,
    `products`    LONGTEXT NOT NULL COMMENT 'JSON snapshot',
    `grand_total` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `paid`        DECIMAL(14,2) NOT NULL DEFAULT 0,
    `created_at`  DATETIME NOT NULL,
    FOREIGN KEY (`kasir_id`) REFERENCES `kasir`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Seed Data
-- ============================================================

-- Default admin kasir (password: admin123)
INSERT IGNORE INTO `kasir` (`username`, `email`, `password`) VALUES
('admin', 'admin@limulinstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Kategori default
INSERT IGNORE INTO `kategori` (`nama`, `alias`) VALUES
('Minuman', 'MIN'),
('Makanan', 'MAK'),
('Snack', 'SNK'),
('Kebersihan', 'KBR'),
('Kesehatan', 'KSH'),
('Sembako', 'SMB');

-- Contoh Produk
INSERT IGNORE INTO `produk` (`name`, `sku`, `kategori_id`, `berat`, `price`, `discount`, `stock`, `sold`) VALUES
('Aqua Botol', 'MIN-AQUABOT-600', 1, 600, 4000, 0, 50, 0),
('Teh Botol Sosro', 'MIN-TEHBOTS-350', 1, 350, 5000, 5, 40, 0),
('Indomie Goreng', 'MAK-INDOMIEG-85', 2, 85, 3500, 0, 100, 0),
('Chitato Original', 'SNK-CHITATO-68', 3, 68, 12000, 10, 30, 0),
('Sabun Lifebuoy', 'KBR-SABUNLIF-90', 4, 90, 8500, 0, 25, 0),
('Beras Premium 5kg', 'SMB-BERASPRE-5000', 6, 5000, 65000, 0, 20, 0),
('Gula Pasir 1kg', 'SMB-GULAPAS-1000', 6, 1000, 14000, 0, 30, 0),
('Minyak Goreng 1L', 'SMB-MINYAKGO-1000', 6, 1000, 18000, 0, 25, 0);
