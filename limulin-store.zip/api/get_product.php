<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

session_start_safe();
if (empty($_SESSION['cashier_id'])) {
    json_response(['success' => false, 'message' => 'Unauthorized'], 401);
}

$sku = strtoupper(trim(get('sku')));
if (!$sku) {
    json_response(['success' => false, 'message' => 'SKU kosong']);
}

$product = DB::fetchOne(
    'SELECT p.*, k.nama as kategori_nama FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id WHERE UPPER(p.sku) = ?',
    [$sku]
);

if (!$product) {
    json_response(['success' => false, 'message' => "Produk dengan SKU '$sku' tidak ditemukan"]);
}

json_response(['success' => true, 'product' => $product]);
