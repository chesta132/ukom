<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

session_start_safe();
if (empty($_SESSION['cashier_id'])) {
    json_response([], 401);
}

$q = '%' . trim(get('q')) . '%';
$products = DB::fetchAll(
    'SELECT p.*, k.nama as kategori_nama FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id 
     WHERE (p.name LIKE ? OR p.sku LIKE ?) LIMIT 20',
    [$q, $q]
);

header('Content-Type: application/json');
echo json_encode($products);
