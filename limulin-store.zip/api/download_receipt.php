<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

session_start_safe();
if (empty($_SESSION['cashier_id'])) {
    http_response_code(401);
    exit('Unauthorized');
}

$id = (int)get('id');
if (!$id) { http_response_code(400); exit('Bad Request'); }

$trx = DB::fetchOne(
    'SELECT t.*, k.username as cashier_name FROM transaksi t LEFT JOIN kasir k ON t.kasir_id = k.id WHERE t.id = ?',
    [$id]
);
if (!$trx) { http_response_code(404); exit('Not Found'); }

$products = json_decode($trx['products'], true);

// Generate HTML-based PDF via browser print hack — use simple HTML page for PDF
// We generate a printable HTML page instead, which user can save as PDF
header('Content-Type: text/html; charset=UTF-8');

$date = date('d/m/Y H:i', strtotime($trx['created_at']));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Struk <?= sanitize($trx['kode']) ?></title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Courier New', monospace; font-size:12px; max-width:300px; margin:0 auto; padding:10px; }
.header { text-align:center; margin-bottom:8px; }
.header h1 { font-size:14px; }
.divider { border-top:1px dashed #000; margin:6px 0; }
table { width:100%; border-collapse:collapse; }
th, td { padding:2px 0; font-size:11px; }
th { text-align:left; font-weight:bold; }
.right { text-align:right; }
.total-row { display:flex; justify-content:space-between; font-weight:bold; margin:4px 0; font-size:12px; }
.sum-row { display:flex; justify-content:space-between; font-size:11px; margin:2px 0; }
.footer { text-align:center; font-size:11px; margin-top:8px; }
@media print { @page { margin:0; size: 80mm auto; } }
</style>
</head>
<body onload="window.print()">
<div class="header">
    <h1><?= APP_NAME ?></h1>
    <p><?= APP_ADDRESS ?></p>
    <p><?= $date ?></p>
    <p>No: <?= sanitize($trx['kode']) ?></p>
    <p>Kasir: <?= sanitize($trx['cashier_name']) ?></p>
</div>
<div class="divider"></div>
<table>
    <thead><tr><th>Item</th><th class="right">Qty</th><th class="right">Harga</th><th class="right">Subtotal</th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): ?>
        <?php
        $net = $p['price'] - ($p['price'] * ($p['discount'] / 100));
        $sub = $net * $p['qty'];
        ?>
        <tr>
            <td><?= sanitize($p['name']) ?><?= $p['discount'] > 0 ? ' (-'.$p['discount'].'%)' : '' ?></td>
            <td class="right"><?= $p['qty'] ?></td>
            <td class="right"><?= format_rupiah($net) ?></td>
            <td class="right"><?= format_rupiah($sub) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<div class="divider"></div>
<div class="total-row"><span>TOTAL</span><span><?= format_rupiah($trx['grand_total']) ?></span></div>
<div class="sum-row"><span>Bayar</span><span><?= format_rupiah($trx['paid']) ?></span></div>
<div class="sum-row"><span>Kembali</span><span><?= format_rupiah($trx['paid'] - $trx['grand_total']) ?></span></div>
<div class="divider"></div>
<div class="footer">
    <p>Terima kasih telah berbelanja!</p>
    <p>Barang yang sudah dibeli</p>
    <p>tidak dapat dikembalikan.</p>
</div>
</body>
</html>
