<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

session_start_safe();
if (empty($_SESSION['cashier_id'])) {
    json_response(['success' => false, 'message' => 'Unauthorized'], 401);
}

$input = json_decode(file_get_contents('php://input'), true);
$cartItems = $input['cart'] ?? [];
$paid      = floatval($input['paid'] ?? 0);

if (empty($cartItems)) {
    json_response(['success' => false, 'message' => 'Keranjang kosong']);
}

$conn = DB::connect();

try {
    $conn->begin_transaction();

    $grandTotal = 0;
    $productsList = [];

    foreach ($cartItems as $item) {
        $product = DB::fetchOne('SELECT * FROM produk WHERE id = ? FOR UPDATE', [(int)$item['id']]);
        if (!$product) throw new Exception("Produk ID {$item['id']} tidak ditemukan");
        if ($product['stock'] < (int)$item['qty']) throw new Exception("Stok {$product['name']} tidak mencukupi");

        $net = $product['price'] - ($product['price'] * ($product['discount'] / 100));
        $subtotal = $net * (int)$item['qty'];
        $grandTotal += $subtotal;

        DB::query('UPDATE produk SET stock = stock - ?, sold = sold + ? WHERE id = ?',
            [(int)$item['qty'], (int)$item['qty'], $product['id']]);

        $productsList[] = [
            'id'       => $product['id'],
            'name'     => $product['name'],
            'sku'      => $product['sku'],
            'price'    => (float)$product['price'],
            'discount' => (float)$product['discount'],
            'qty'      => (int)$item['qty'],
            'subtotal' => $subtotal,
        ];
    }

    if ($paid < $grandTotal) throw new Exception('Pembayaran kurang');

    $kode = generate_trx_code();
    $trxId = DB::insert('transaksi', [
        'kode'        => $kode,
        'kasir_id'    => $_SESSION['cashier_id'],
        'products'    => json_encode($productsList),
        'grand_total' => $grandTotal,
        'paid'        => $paid,
        'created_at'  => date('Y-m-d H:i:s'),
    ]);

    $conn->commit();

    $user = DB::fetchOne('SELECT username FROM kasir WHERE id = ?', [$_SESSION['cashier_id']]);

    json_response([
        'success' => true,
        'transaction' => [
            'id'           => $trxId,
            'kode'         => $kode,
            'products'     => $productsList,
            'grand_total'  => $grandTotal,
            'paid'         => $paid,
            'change'       => $paid - $grandTotal,
            'cashier_name' => $user['username'],
            'created_at'   => date('Y-m-d H:i:s'),
        ]
    ]);

} catch (Exception $e) {
    $conn->rollback();
    json_response(['success' => false, 'message' => $e->getMessage()]);
}
