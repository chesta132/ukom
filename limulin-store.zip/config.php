<?php
ob_start(); // Buffer output agar redirect() tidak error "headers already sent"
// ============================================================
// LIMULIN STORE - Config
// ============================================================

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'limulin_store');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Limulin Store');
define('APP_ADDRESS', 'Jl Wibawa Mukti II, Jatisari Jatiasih Kota Bekasi');
define('APP_PHONE', '');
define('APP_SECRET', 'LIMULIN2024SECRET'); // Secret untuk registrasi kasir

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$basePath = ($scriptPath !== '/') ? $scriptPath : '';
define('BASE_URL', $protocol . '://' . $host);

define('SESSION_TIMEOUT', 3600 * 8); // 8 jam
