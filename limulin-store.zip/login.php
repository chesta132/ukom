<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

auth_guest();

$error = '';
if (is_post()) {
    $username = post('username');
    $password = post('password');
    if (empty($username) || empty($password)) {
        $error = 'Username dan password wajib diisi.';
    } elseif (!login($username, $password)) {
        $error = 'Username atau password salah.';
    } else {
        redirect(BASE_URL . '/index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <i class="fas fa-store"></i>
            <h1><?= APP_NAME ?></h1>
            <p><?= APP_ADDRESS ?></p>
        </div>
        <div class="auth-title">Masuk ke Sistem Kasir</div>
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?= sanitize($error) ?></div>
        <?php endif; ?>
        <?php if (!empty($_GET['timeout'])): ?>
        <div class="alert alert-info"><i class="fas fa-clock"></i>Sesi habis, silakan login kembali.</div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label"><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" value="<?= sanitize(post('username')) ?>" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label"><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100" style="justify-content:center;padding:10px;">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
        <div class="auth-footer">
            Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar di sini</a>
        </div>
    </div>
</div>
</body>
</html>
