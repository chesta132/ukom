**CARA MEMAKAINYA DI UBUNTU**

# INSTALL

```bash
sudo apt install apache2 git -y
```

# CLONE DARI GITHUB

```bash
sudo rm -rf /var/www/html
sudo git clone https://github.com/<username_github>/<repository_github> /var/www/html
```

# UNZIP FILE JIKA YANG DI-UPLOAD KE GITHUB ADALAH FILE ZIP

```bash
sudo apt install unzip -y
cd /var/www/html
ls
```

Akan muncul file yang ada di /var/www/html, temukan yang .zip

```bash
sudo unzip chardymart-pos.zip
```

Saya memberikan chardymart-pos.zip karena file saya bernama itu, ubah sesuai nama file kalian

# UBAH CONFIG (OPSIONAL)

```bash
cd /var/www/html
sudo nano config.php
```

Pada bagian berikut, ubah sesuai kebutuhan tetapi ini opsional

```php
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
```

# INIT DATABASE

```bash
sudo mysql -u root
```

```sql
SOURCE /var/www/html/database.sql;
```

**SILAHKAN AKSES MELALUI UBUNTU**

# INFO

Akun yang ter-regist
username = admin
password = password
