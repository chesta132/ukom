<?php
$page_title = 'Kasir';
require_once __DIR__ . '/includes/header.php';
?>

<div class="pos-layout">
    <!-- LEFT: Input & Cart -->
    <div class="pos-left">
        <!-- SKU Input -->
        <div class="card">
            <div class="card-body" style="padding:12px 16px;">
                <form id="skuForm" onsubmit="handleSkuInput(event)" autocomplete="off">
                    <div class="sku-input-row">
                        <input type="text" id="skuInput" class="form-control" placeholder="Scan / ketik SKU produk..." autofocus>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah</button>
                        <button type="button" class="btn btn-outline" onclick="openSearchProduct()"><i class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Cart -->
        <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column;">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-shopping-cart"></i> Keranjang Belanja</div>
                <span id="cartCount" class="badge badge-blue">0 item</span>
            </div>
            <div class="cart-wrapper">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Diskon</th>
                            <th class="text-center">Qty</th>
                            <th class="text-right">Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cartBody">
                        <tr id="cartEmpty">
                            <td colspan="6">
                                <div class="cart-empty">
                                    <i class="fas fa-shopping-cart"></i>
                                    <p>Keranjang kosong<br><small>Scan atau masukkan SKU produk</small></p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- RIGHT: Checkout -->
    <div class="pos-right">
        <div class="pos-checkout">
            <div class="checkout-summary">
                <div class="card-title" style="margin-bottom:12px;"><i class="fas fa-receipt"></i> Ringkasan</div>
                <div class="checkout-row"><span>Subtotal</span><span id="summarySubtotal">Rp 0</span></div>
                <div class="checkout-row"><span>Total Diskon</span><span id="summaryDiscount" class="text-danger">-Rp 0</span></div>
                <div class="checkout-row checkout-total"><span>TOTAL</span><span id="summaryTotal">Rp 0</span></div>
            </div>
            <div class="checkout-payment">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Uang Bayar</label>
                    <input type="number" id="paymentInput" class="form-control" placeholder="0" min="0" oninput="calcChange()">
                </div>
            </div>
            <div class="checkout-change">
                <div class="checkout-change-row">
                    <span>Kembalian</span>
                    <span id="changeAmount">Rp 0</span>
                </div>
            </div>
            <div class="checkout-btn">
                <button class="btn btn-success" onclick="processCheckout()">
                    <i class="fas fa-check-circle"></i> Proses Transaksi
                </button>
                <button class="btn btn-secondary checkout-btn" onclick="clearCart()">
                    <i class="fas fa-trash"></i> Bersihkan
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Search Product Modal -->
<div id="searchModal" class="modal-overlay">
    <div class="modal modal-lg">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-search"></i> Cari Produk</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="form-control mb-2" placeholder="Nama / SKU produk..." oninput="searchProducts(this.value)">
            <div class="table-wrapper" style="max-height:360px;overflow-y:auto;">
                <table><thead><tr><th>SKU</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th></th></tr></thead>
                <tbody id="searchResults"><tr><td colspan="6" class="text-center text-muted" style="padding:20px">Ketik untuk mencari...</td></tr></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Receipt Modal -->
<div id="receiptModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-receipt"></i> Struk Transaksi</div>
            <button class="modal-close"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div id="receiptContent"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary modal-close"><i class="fas fa-times"></i> Tutup</button>
            <button class="btn btn-outline" onclick="printReceipt()"><i class="fas fa-print"></i> Print</button>
        </div>
    </div>
</div>

<!-- Flash -->
<?php if ($f = flash_get('success')): ?>
<div id="flashToast" data-msg="<?= sanitize($f) ?>" data-type="success" style="display:none"></div>
<?php endif; ?>

<script>
let cart = [];
let lastTrxData = null;

// Format rupiah
function fmtRp(n) {
    return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// Handle SKU input
async function handleSkuInput(e) {
    e.preventDefault();
    const sku = document.getElementById('skuInput').value.trim().toUpperCase();
    if (!sku) return;
    await addBySku(sku);
    document.getElementById('skuInput').value = '';
    document.getElementById('skuInput').focus();
}

async function addBySku(sku) {
    const res = await fetch('api/get_product.php?sku=' + encodeURIComponent(sku));
    const data = await res.json();
    if (!data.success) {
        showToast(data.message || 'Produk tidak ditemukan', 'error');
        return;
    }
    addToCart(data.product);
}

function addToCart(product) {
    const existing = cart.find(i => i.id === product.id);
    if (existing) {
        if (existing.qty >= product.stock) {
            showToast('Stok tidak mencukupi', 'error');
            return;
        }
        existing.qty++;
    } else {
        if (product.stock < 1) {
            showToast('Stok habis!', 'error');
            return;
        }
        cart.push({ ...product, qty: 1 });
    }
    renderCart();
    showToast(product.name + ' ditambahkan', 'success');
}

function removeFromCart(id) {
    cart = cart.filter(i => i.id !== id);
    renderCart();
}

function changeQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) removeFromCart(id);
    else if (item.qty > item.stock) { item.qty = item.stock; showToast('Stok tidak mencukupi', 'error'); }
    else renderCart();
}

function renderCart() {
    const tbody = document.getElementById('cartBody');
    const empty = document.getElementById('cartEmpty');
    
    if (cart.length === 0) {
        tbody.innerHTML = `<tr id="cartEmpty"><td colspan="6"><div class="cart-empty"><i class="fas fa-shopping-cart"></i><p>Keranjang kosong<br><small>Scan atau masukkan SKU produk</small></p></div></td></tr>`;
        updateSummary();
        return;
    }

    let html = '';
    cart.forEach(item => {
        const discountAmt = item.price * (item.discount / 100);
        const netPrice = item.price - discountAmt;
        const subtotal = netPrice * item.qty;
        html += `<tr>
            <td>
                <div style="font-weight:600">${escHtml(item.name)}</div>
                <small class="text-muted">${escHtml(item.sku)}</small>
            </td>
            <td>${fmtRp(item.price)}</td>
            <td>${item.discount > 0 ? '<span class="badge badge-red">-'+item.discount+'%</span>' : '-'}</td>
            <td class="text-center">
                <div class="qty-control">
                    <button onclick="changeQty(${item.id}, -1)"><i class="fas fa-minus"></i></button>
                    <span>${item.qty}</span>
                    <button onclick="changeQty(${item.id}, 1)"><i class="fas fa-plus"></i></button>
                </div>
            </td>
            <td class="text-right fw-bold">${fmtRp(subtotal)}</td>
            <td><button class="btn btn-sm btn-danger btn-icon" onclick="removeFromCart(${item.id})"><i class="fas fa-trash"></i></button></td>
        </tr>`;
    });
    tbody.innerHTML = html;
    updateSummary();
}

function updateSummary() {
    let subtotal = 0, discount = 0;
    cart.forEach(item => {
        const s = item.price * item.qty;
        const d = s * (item.discount / 100);
        subtotal += s;
        discount += d;
    });
    const total = subtotal - discount;
    document.getElementById('summarySubtotal').textContent = fmtRp(subtotal);
    document.getElementById('summaryDiscount').textContent = '-' + fmtRp(discount);
    document.getElementById('summaryTotal').textContent = fmtRp(total);
    document.getElementById('cartCount').textContent = cart.reduce((s, i) => s + i.qty, 0) + ' item';
    calcChange();
}

function calcChange() {
    let total = 0;
    cart.forEach(item => {
        const net = item.price - (item.price * item.discount / 100);
        total += net * item.qty;
    });
    const paid = parseFloat(document.getElementById('paymentInput').value) || 0;
    const change = paid - total;
    document.getElementById('changeAmount').textContent = fmtRp(change >= 0 ? change : 0);
}

function clearCart() {
    if (cart.length === 0) return;
    confirmAction('Bersihkan Keranjang', 'Yakin ingin menghapus semua item?', () => {
        cart = [];
        document.getElementById('paymentInput').value = '';
        renderCart();
    });
}

async function processCheckout() {
    if (cart.length === 0) { showToast('Keranjang kosong!', 'error'); return; }
    
    let total = 0;
    cart.forEach(item => {
        const net = item.price - (item.price * item.discount / 100);
        total += net * item.qty;
    });
    
    const paid = parseFloat(document.getElementById('paymentInput').value) || 0;
    if (paid < total) { showToast('Uang bayar kurang!', 'error'); return; }

    const res = await fetch('api/process_transaction.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cart, paid })
    });
    const data = await res.json();
    if (!data.success) { showToast(data.message || 'Transaksi gagal', 'error'); return; }
    
    lastTrxData = data.transaction;
    showReceipt(data.transaction);
    cart = [];
    document.getElementById('paymentInput').value = '';
    renderCart();
    showToast('Transaksi berhasil!', 'success');
}

// ============================================================
// Search Product
// ============================================================
function openSearchProduct() {
    openModal('searchModal');
    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').innerHTML = '<tr><td colspan="6" class="text-center text-muted" style="padding:20px">Ketik untuk mencari...</td></tr>';
    setTimeout(() => document.getElementById('searchInput').focus(), 100);
}

let searchTimer;
function searchProducts(q) {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(async () => {
        if (!q.trim()) { document.getElementById('searchResults').innerHTML = '<tr><td colspan="6" class="text-center text-muted" style="padding:20px">Ketik untuk mencari...</td></tr>'; return; }
        const res = await fetch('api/search_product.php?q=' + encodeURIComponent(q));
        const data = await res.json();
        const tbody = document.getElementById('searchResults');
        if (!data.length) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted" style="padding:20px">Tidak ada produk</td></tr>'; return; }
        tbody.innerHTML = data.map(p => `<tr>
            <td><code>${escHtml(p.sku)}</code></td>
            <td>${escHtml(p.name)}</td>
            <td>${escHtml(p.kategori_nama || '-')}</td>
            <td>${fmtRp(p.price)}</td>
            <td>${p.stock > 0 ? '<span class="badge badge-green">'+p.stock+'</span>' : '<span class="badge badge-red">Habis</span>'}</td>
            <td><button class="btn btn-sm btn-primary" onclick="addToCartFromSearch(${p.id})"><i class="fas fa-plus"></i> Tambah</button></td>
        </tr>`).join('');
        window._searchProducts = data;
    }, 300);
}

function addToCartFromSearch(id) {
    const p = window._searchProducts.find(x => x.id == id);
    if (p) addToCart(p);
    closeModal('searchModal');
}

// ============================================================
// Receipt
// ============================================================
function showReceipt(trx) {
    const html = buildReceiptHtml(trx);
    document.getElementById('receiptContent').innerHTML = html;
    openModal('receiptModal');
}

function buildReceiptHtml(trx) {
    const now = new Date(trx.created_at || Date.now());
    const dateStr = now.toLocaleString('id-ID');
    let itemsHtml = trx.products.map(p => {
        const net = p.price - (p.price * (p.discount||0) / 100);
        return `<tr>
            <td>${escHtml(p.name)}</td>
            <td class="text-right">${p.qty}</td>
            <td class="text-right">${fmtRp(net)}</td>
            <td class="text-right">${fmtRp(net * p.qty)}</td>
        </tr>`;
    }).join('');

    return `<div class="receipt" id="printableReceipt">
        <div class="receipt-header">
            <h2><?= APP_NAME ?></h2>
            <p><?= APP_ADDRESS ?></p>
            <p>${dateStr}</p>
            <p>No: ${trx.kode}</p>
            <p>Kasir: ${escHtml(trx.cashier_name)}</p>
        </div>
        <div class="receipt-divider"></div>
        <table class="receipt-items" width="100%">
            <thead><tr><th>Item</th><th class="text-right">Qty</th><th class="text-right">Harga</th><th class="text-right">Total</th></tr></thead>
            <tbody>${itemsHtml}</tbody>
        </table>
        <div class="receipt-divider"></div>
        <div class="receipt-total"><span>TOTAL</span><span>${fmtRp(trx.grand_total)}</span></div>
        <div style="display:flex;justify-content:space-between;font-size:11px;margin-top:4px;">
            <span>Bayar</span><span>${fmtRp(trx.paid)}</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;">
            <span>Kembali</span><span>${fmtRp(trx.change)}</span>
        </div>
        <div class="receipt-divider"></div>
        <div class="receipt-footer">
            <p>Terima kasih telah berbelanja!</p>
            <p>Barang yang sudah dibeli tidak dapat dikembalikan.</p>
        </div>
    </div>`;
}

function printReceipt() {
    const content = document.getElementById('printableReceipt').outerHTML;
    const win = window.open('', '_blank');
    win.document.write(`<html><head><title>Struk</title>
    <style>
        body { font-family: 'Courier New', monospace; font-size: 12px; max-width:300px; margin:0 auto; padding:10px; }
        table { width:100%; border-collapse:collapse; }
        th,td { padding:2px 0; }
        .text-right { text-align:right; }
        .receipt-header { text-align:center; margin-bottom:6px; }
        .receipt-header h2 { font-size:14px; }
        .receipt-divider { border-top:1px dashed #000; margin:6px 0; }
        .receipt-total { display:flex; justify-content:space-between; font-weight:bold; }
        .receipt-footer { text-align:center; font-size:11px; margin-top:6px; }
    </style></head><body>${content}</body></html>`);
    win.document.close();
    win.print();
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
